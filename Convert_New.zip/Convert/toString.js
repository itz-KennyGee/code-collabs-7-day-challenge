
function toString(num) {
    var units = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
    var tenplus = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    var tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    var power = ['', '', 'hundred', 'thousand'];
    
     num = document.getElementById("num").value;
      var readout = '';
    
      number = num.toString();
      // number = number.split("");
      var length = number.length;
    
      if (num == 0) {
          readout = 'zero'
      } else if (length == 1) {
          readout = (units[number])
      } else if (length == 2) {
          if (number[0] == '1') {
              readout = (tenplus[number[1]])
          } else {
              if (number[1] == '0') { readout = tens[number[0]] } else {
                  readout = tens[number[0]] + ' ' + units[number[1]]
              }
          }
      } else if (length >= 3) {
          var i = 0;
          while (i < length - 2) {
              if (number[i] > 0) {
                  readout = readout.concat(units[number[i]] + ' ' + power[length - (i + 1)] + ' ');
              } else { readout = readout.concat(' ') }
              i++;
          }
          if ((i = length - 2) && (number[i] > 0)) { //maybe while instead of if?
              if (number[i] == 1) {
                  readout = readout.concat('and ' + tenplus[number[i + 1]])
              } else if (number[i] > 1) {
                  readout = readout.concat('and ' + tens[number[i]] + ' ' + units[number[i + 1]])
              }
          } else if ((number[i] == 0) && number[i + 1] > 0) { readout = readout.concat('and ' + units[number[i + 1]]) }
          else { readout = readout }
      }
    
      if (length > 4) { readout = "Sorry, numbers above 9999 not supported." }
    
      return readout;
    }
    
    
    function myFunction() {
       
      document.getElementById("demo-string").innerHTML =  toString(num);
      }
    
    