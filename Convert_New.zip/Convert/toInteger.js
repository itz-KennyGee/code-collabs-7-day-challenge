function toInteger(words) {
    var units = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
    var tenplus = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    var tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    var power = ['', '', 'hundred', 'thousand'];
    
    words = document.getElementById("words").value;
    words = words.toLowerCase();
    
    words = words.split(' ');
    if (words.indexOf('and') > -1) { words.splice(words.indexOf('and'), 1) }
    var length = words.length;
    var int = 0;


    for (var i = length - 1; i >= 0; i--) {
        if (units.indexOf(words[i]) > -1) {
            int += units.indexOf(words[i]);
        } else if (tenplus.indexOf(words[i]) > -1) {
            int += 10 + tenplus.indexOf(words[i]);
        } else if (tens.indexOf(words[i]) > -1) {
            int += 10 * tens.indexOf(words[i]); // last 2 digits sorted 
        } if (power.indexOf(words[i]) > 1) {
            int += (10 ** power.indexOf(words[i])) * (units.indexOf(words[i - 1]));
            i--
        }

    }
    return int

}

function myFunction2() {
    document.getElementById("demo-number").innerHTML = toInteger(words);
}