

    function permit() {
      
    var x = document.getElementById("outside").value;

    var joblist = document.getElementById("job-select");
    var message = document.getElementById("message");

    if  (x == "no") {
        message.style.display = "block"
        joblist.style.display = "none"
        document.getElementById("message").innerHTML = "You're doing the right thing. Stay indoors and Stay Safe!";
        message.style.color = "black";
    } else if (x == "yes") {
        joblist.style.display = "block"
    }  else if (x == "empty"){
        document.getElementById("message").innerHTML = "We'd appreciate if you told us to help advise you properly";
        message.style.color = "red";
    } else if (x == "select") {
        message.style.display = "none"
    }

    }

    function myFunction() {  
       permit();
    }

    function jobmessage() {
        var x = document.getElementById("job").value;
        var message = document.getElementById("job-message");
        

        if (x == "select") {
            message.style.display = "none"; 
        } else if (x == "essential") {
            message.style.display = "block"
            message.style.color = "black"
            document.getElementById("job-message").innerHTML = "Stay Safe out there!"
        } else if (x == "healthcare") {
            message.style.display = "block"
            message.style.color = "black"
            document.getElementById("job-message").innerHTML = "Thank you NHS! Stay Safe out there!"
        } else if (x == "not-essential") {
            message.style.display = "block"
            message.style.color = "red"
            document.getElementById("job-message").innerHTML = "Please stay at and work from home!"
        } else if (x == "other") {
            message.style.display = "block"
            message.style.color = "black"
            document.getElementById("job-message").innerHTML = "We do advise that you stay at home for your own safety."
        }

    }

    function myFunction2() {
        jobmessage();
    }